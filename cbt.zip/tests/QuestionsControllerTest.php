<?php
/**
 * Created by PhpStorm.
 * User: EP
 * Date: 5/23/2015
 * Time: 10:23 PM
 */

namespace app\Http\Controllers;


class QuestionsControllerTest extends \PHPUnit_Framework_TestCase {

}
