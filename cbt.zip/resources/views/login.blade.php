@include('layout.loginHeader')
	@yield('content')
@include('layout.footer')