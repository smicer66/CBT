<?php

$boolval = true;

echo (string) $boolval;
?>